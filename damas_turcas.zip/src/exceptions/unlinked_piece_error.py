class UnlinkedPieceError(Exception):
    pass