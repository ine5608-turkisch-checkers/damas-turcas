class PromotionError(Exception):
    pass