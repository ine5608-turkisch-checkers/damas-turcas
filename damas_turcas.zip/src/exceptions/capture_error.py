class CaptureError(Exception):
    pass