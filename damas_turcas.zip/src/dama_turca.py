import player_interface

player_interface.PlayerInterface()
